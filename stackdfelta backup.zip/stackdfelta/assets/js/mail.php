<?php

$message = '';


if (isset($_POST["submit"])) {
    $path = 'upload/' . $_FILES["resume"]["name"];
    move_uploaded_file($_FILES["resume"]["tmp_name"], $path);
    $message = '
		<h3 align="center">Applicant Details</h3>
		<table border="1" width="100%" cellpadding="5" cellspacing="5">
			<tr>
				<td width="30%">Name</td>
				<td width="70%">' . $_POST["name"] . '</td>
			</tr>
			<tr>
				<td width="30%">Email Address</td>
				<td width="70%">' . $_POST["email"] . '</td>
			</tr>
			<tr>
				<td width="30%">Area of Interest</td>
				<td width="70%">' .$_POST["msg_subject"] . '</td>
			</tr>
			<tr>
				<td width="30%">Massage</td>
				<td width="70%">' . $_POST["msg_subject"] . '</td>
			</tr>
			<tr>
				<td width="30%">Phone Number</td>
				<td width="70%">' . $_POST["phone_number"] . '</td>
			</tr>
			<tr>
				<td width="30%">message</td>
				<td width="70%">' . $_POST["message"] . '</td>
			</tr>
		</table>
	';

    use PHPMailer\PHPMailer;
    use PHPMailer\Exception;

    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    $mail = new PHPMailer(true);                              

    try {
        //Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'intellecttec@gmail.com';                     //SMTP username
        $mail->Password   = 'bzsgrxiakqlxfqjz';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('intellecttec@gmail.com', 'Mailer');
        $mail->addAddress('stackdeltaa@gmail.com');
        $mail->addBCC('uniqueupgradevddr@gmail.com');

        //Attachments
        $mail->addAttachment($path);         //Add attachments
       

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Application for JOB';
        $mail->Body    = $message;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        echo 'success';
        } 
    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
?>