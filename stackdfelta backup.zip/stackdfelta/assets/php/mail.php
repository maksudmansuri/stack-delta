<?php
    $filenameee =  $_FILES['resume']['name'];
    $fileName = $_FILES['resume']['tmp_name']; 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $folder="files/";
    $phone_number = $_POST['phone_number'];
    $usermessage = $_POST['message'];
    $purpose = $_POST['msg_subject'];
    move_uploaded_file($_FILES["resume"]["tmp_name"], "$folder".$_FILES["resume"]["name"]);
    $message ="Name = ". $name . "\r\n  Email = " . $email . "\r\n  Phone = " . $phone_number ."\r\n  Area of Interest = " . $purpose . "\r\n Message =" . $usermessage; 
    
    $subject ="Resume file";
    $fromname ="stack deltas";
    $fromemail = 'info@stackdelta.com';  //if u dont have an email create one on your cpanel
    $mailto = 'uniqueupgradevddr@gmail.com';  //the email which u want to recv this 
    // main header (multipart mandatory)
  
    require_once('class.phpmailer.php');	
    $send_mail = new PHPMailer();
    $send_mail->From = $email;
    $send_mail->FromName = $name;
    $send_mail->Subject = $subject;
    $send_mail->Body = $message;
    $send_mail->AddAddress($mailto);

    $attach_file = $folder."".$file_name;
    $send_mail->AddAttachment($attach_file);
    echo "success";
    return $send_mail->Send();
   

    
?>